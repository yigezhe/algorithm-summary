// Jeff Somers
// 1/7/2000

public final class patzException extends Exception
{
	// intentionally blank for now
	// At this point, this is just used for
	// Asserts, so not much to add here

	// constructor
	patzException(String s)
	{
		super(s);
	}
}